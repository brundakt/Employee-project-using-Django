#from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.views.generic import TemplateView
from eapp.forms import EmployeeCreate
from eapp.models import Employee
# Create your views here.
class Home(TemplateView):
	template_name = 'home.html'
def register(request):
	upload = EmployeeCreate()
	if request.method == 'POST':
		upload = EmployeeCreate(request.POST,request.FILES)
		if upload.is_valid():
			upload.save()
			return redirect('home')
		else:
			return HttpResponse("""Invalid attributes,reload on <a href="{{ url 'home' }}">Reload</a>""")
	else:
		return render(request, 'insert.html', {'updat': upload})
def display(request):
	shelf = Employee.objects.all()
	return render(request, 'display.html', {'shelf': shelf})
def update(request, id):
	id = int(id)
	try:
		emp = Employee.objects.get(id=id)
	except Employee.DoesNotExist:
		return redirect('display')
	sform = EmployeeCreate(request.POST or None,instance=emp)
	if sform.is_valid():
		sform.save()
		return redirect('display')
	else:
		return render(request, 'insert.html', {'updat': sform})
def delete(request, id):
	updatevar = Employee.objects.get(id=id)
	updatevar.delete()
	return redirect('display')
