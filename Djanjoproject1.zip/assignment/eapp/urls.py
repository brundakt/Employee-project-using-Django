from django.urls import path,include
from eapp import views
from eapp.views import Home
urlpatterns = [
	path('home/', Home.as_view(), name='home'),
	path('insert/', views.register, name='insert'),
	path('display/',views.display, name='display'),
	path('update/<int:id>',views.update),
	path('delete/<int:id>',views.delete,name = 'delete'),
]

