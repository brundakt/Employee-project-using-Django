from django.apps import AppConfig


class EappConfig(AppConfig):
    name = 'eapp'
